function noNewTab(location) {
    window.location.href=location;
}
  
function newTab() {
    window.open(location, "_blank");
}
