## Asennus

- PHP-demo (news)
- Lataa tämä koodi .zip-tiedostona githubista, pura paketti  (tai kloonaa ja poista .git kansio)
- Asenna XAMPP
- Käynnistä XAMPP, tee sinne tietokanta jonka nimi on "news" ja vie sinne PhpMyAdminillä tietokanta kansiosta database_dump
- Siirry projektin juureen: cd news_2021
- Siirry kansioon public: cd public
- Käynnistä serveri: php -S localhost:8888
- Avaa selaimessa: localhost:8888
