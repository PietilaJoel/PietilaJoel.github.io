<?php require "partials/head.php"; ?>

<h2 class="centered">Omat tiedot</h2>

<div class = "news">

</div>

<?php require "partials/footer.php"; ?>