<footer class="centeredtext">2025 copyright JJN ©</footer>
</body>
</html>